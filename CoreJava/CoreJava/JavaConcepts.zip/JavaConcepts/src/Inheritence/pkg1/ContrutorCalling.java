package Inheritence.pkg1;
class ParentInfo{
	ParentInfo(){
		this("hello");
		System.out.println("Parent's information");
	}
	ParentInfo(String msg ){
		System.out.println(msg);
	}
}
class ChildInfo extends ParentInfo{
	ChildInfo(){
		super(); //automatically add by compiler to call default 
		//super("hello");//calling of parent class constructor
		System.out.println("Child's Information");
	}
	
}
public class ContrutorCalling {

	public static void main(String[] args) {
		ChildInfo child=new ChildInfo();

	}

}
