package Inheritence.pkg1;

public class Child1 extends Parent {

		void show() {
			//method1();
			method2();
			method3();
			method4();
		}
}
