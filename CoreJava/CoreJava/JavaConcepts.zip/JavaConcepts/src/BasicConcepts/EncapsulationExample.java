package BasicConcepts;
class Person{
	private String name;
	private int age;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name=name;
	}
	public void setAge(int age){
		this.age=age;
	}
	public int getAge() {
		return age;
	}
	
}

public class EncapsulationExample {

	public static void main(String[] args) {
		Person p=new Person(); 
		p.setName("Nikita");
		System.out.println(p.getName());

	}

}
