package Inheritence.pkg1;
class Person{
	private int id;
	private String name;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
}

class Student extends Person{
	private float marks;

	public float getMarks() {
		return marks;
	}

	public void setMarks(float marks) {
		this.marks = marks;
	}
	
	
}

class Employee extends Person{
	private float salary;

	public float getSalary() {
		return salary;
	}

	public void setSalary(float salary) {
		this.salary = salary;
	}
	
	
}
public class IsARealtionship {

	public static void main(String[] args) {
		Student student=new Student();
		student.setId(1);
		student.setName("Amisha");
		student.setMarks(23.6f);
		
		Employee emp=new Employee();
		emp.setId(2);
		emp.setName("Kavish");
		emp.setSalary(678.9f);
		

	}

}
