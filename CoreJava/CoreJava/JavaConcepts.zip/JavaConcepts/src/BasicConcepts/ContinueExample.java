package BasicConcepts;

public class ContinueExample {

	public static void main(String[] args) {
		int val=3;
		for(int i=1;i<=5;i++) {
			if(i==val)continue;
			System.out.println(i);
		}

	}

}
