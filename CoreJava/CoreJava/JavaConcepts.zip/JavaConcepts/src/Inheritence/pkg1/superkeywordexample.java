package Inheritence.pkg1;
/*class Parent1{
	void show() {
		System.out.println("Parent show method");
	}
}
class Child extends Parent1{
	@Override
	void show() {
		super.show();
		System.out.println("Child show method");
	}
	
}
public class superkeywordexample {

	public static void main(String[] args) {
		
		Child child=new Child();
		child.show();
		
	}

}*/
