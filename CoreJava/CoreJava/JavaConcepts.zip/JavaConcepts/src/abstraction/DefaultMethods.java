package abstraction;
interface ParentA{
	default void method1() {
		System.out.println("Method1");
	}
	//private method- jdk1.9 onwards
	private void method2() {
		System.out.println("private method");
	}
	public static void method3() {
		System.out.println("static method");
	}
	default void show() {
		method2();
		System.out.println("ParentA's show");
	}
}
interface ParentB{
	default void show() {
		System.out.println("ParentB's show");
	}
}
class ChildA implements ParentA,ParentB{
	@Override
	public void show() {
		ParentA.method3();
		method1();
		ParentA.super.show();
		ParentB.super.show();
		System.out.println("ChildA's Method");
		
	}}
public class DefaultMethods {
	public static void main(String[] args) {
		ChildA obj=new ChildA();
		obj.show();
	//ChildA.method3(); Can't call static methods of interface in main
		obj.method1();

	}

}
