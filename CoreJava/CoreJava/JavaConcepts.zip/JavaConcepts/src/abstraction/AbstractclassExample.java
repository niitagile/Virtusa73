package abstraction;
abstract class Microwave{
	void start_stop() {
		System.out.println("ON/Off");
	}
	abstract void temp();
	abstract void time();
}
class Cake extends Microwave{

	@Override
	void temp() {
		System.out.println("Temp method");
		
	}

	@Override
	void time() {
		System.out.println("time method");
		
	}

	
	
}
public class AbstractclassExample {

	public static void main(String[] args) {
		//Microwave obj=new Microwave();
		Microwave obj=new Cake();
		obj.start_stop();
		obj.temp();
		obj.time();
		

	}

}

/*
 abstract class- contains abstract methods and concrete class
 you can't create object of abrstract class
 Child class must define all concrete methods
 */
