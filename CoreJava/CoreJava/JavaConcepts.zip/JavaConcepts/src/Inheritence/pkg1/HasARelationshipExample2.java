package Inheritence.pkg1;
class Address{
	String city,houseno;

	public Address(String city, String houseno) {
		super();
		this.city = city;
		this.houseno = houseno;
	}
	
	void display() {
		System.out.println("Address= "+houseno+" "+city);
	}
}
class EmployeeDetails{
	String name;
	Address adr;
	String department;
	public EmployeeDetails(String name, Address adr, String department) {
		super();
		this.name = name;
		this.adr = adr;
		this.department = department;
	}
	void show() {
		System.out.println("name= "+name);
		adr.display();
		System.out.println("department= "+department);
	}
}
public class HasARelationshipExample2 {

	public static void main(String[] args) {
		
		//Employee emp=new Employee("Harish",new Address("101","Delhi"),"Technical");
	
		Address adr=new Address("Delhi","101");
		EmployeeDetails emp=new EmployeeDetails("Harish",adr,"Technical");
		emp.show();
	}

}
