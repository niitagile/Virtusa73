package Inheritence.pkg1;

public class ClassA {

	void show() {
		Parent p=new Parent();
		//p.method1();
		p.method2();
		p.method3();
		p.method4();
	}
}
