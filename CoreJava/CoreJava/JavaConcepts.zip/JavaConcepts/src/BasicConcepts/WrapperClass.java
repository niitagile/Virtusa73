package BasicConcepts;

public class WrapperClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("byte min="+Byte.MIN_VALUE+" byte max="+ Byte.MAX_VALUE);

		System.out.println("short min="+Short.MIN_VALUE+" short max="+ Short.MAX_VALUE);

		System.out.println("int min="+Integer.MIN_VALUE+" int max="+ Integer.MAX_VALUE);

		System.out.println("long min="+Long.MIN_VALUE+"long max="+ Long.MAX_VALUE);

		System.out.println("float min="+Float.MIN_VALUE+" float max="+ Float.MAX_VALUE);

		System.out.println("double min="+Double.MIN_VALUE+" double max="+ Double.MAX_VALUE);

		System.out.println("char min="+Character.MIN_VALUE+" char max="+ Character.MAX_VALUE);

		//System.out.println("byte min="+Boolean.MIN_VALUE+" byte max="+ Byte.MAX_VALUE);
		
		int a=90;
		System.out.println("hello "+a);

	
	}

}
/*
Wrapper classes- classes equivalent to primitive data types.
convert primitive data type to Object
*/