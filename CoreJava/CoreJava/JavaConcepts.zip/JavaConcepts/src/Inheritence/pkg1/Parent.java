package Inheritence.pkg1;

public class Parent {
	private void method1() {System.out.println("private method");}
	 void method2() {System.out.println("default method");}
	protected void method3() {System.out.println("protected method");}
	public void method4() {System.out.println("public method");}
}
