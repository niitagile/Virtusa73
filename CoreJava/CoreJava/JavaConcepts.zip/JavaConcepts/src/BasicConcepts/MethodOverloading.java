package BasicConcepts;
//when a class contains multiple methods with same name but with different arguments- seequence, type, no
class ClassA{
	void display(String name){
		System.out.println("Method1");
		System.out.println(name);
	}
	
	void display(int num1, float num2) {
		System.out.println("Method2");
		System.out.println(num1);
		System.out.println(num2);
	}
	void display(float num1, float num2) {
		System.out.println("Method3");
		System.out.println(num1);
		System.out.println(num2);
	}
	void display(float num1,int num2) {
		System.out.println("Method4");
		System.out.println(num1);
		System.out.println(num2);
	}
	
	/*float display(float num1,int num2) {
		System.out.println("Method4");
		System.out.println(num1);
		System.out.println(num2);
	return num1+num2;
	}*/
}
public class MethodOverloading {

	public static void main(String[] args) {
		
				ClassA obj = new ClassA();
				obj.display(3.4f, 89);
				
				
	}

}
