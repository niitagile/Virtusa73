package Inheritence.pkg1;
class Parent1{
	void show() {
		System.out.println("Parent show method");
	}
}
class Child extends Parent1{
	@Override
	void show() {
		
		System.out.println("Child show method");
	}
	void method1() {
		System.out.println("Method1");
	}
	
}
public class superkeywordexample2 {

	public static void main(String[] args) {
		//dynamic Dispatching
		Parent1 ptr;
		 ptr=new Parent1();
		ptr.show();
		ptr=new Child();
		ptr.show();
		//ptr.method1(); dynamic dispatching is not possible on methods which are available only in child as well as it is not possible on variables 
		
	}

}
