package BasicConcepts;
import java.lang.*;
public class HelloWorld {

	public static void main(String[] args) {
		//To print any output use System.out.println.
		//system is predefined class,out is object, println is function
		//primitive data types. Compiler always keeps them in internal Stack
		byte vbyte=90;// 0 to 255 or -127 to 128
		
		short vshort=6788;
		int vint=87687;
		long vlong=68768787;
		
		
		float vfloat=89.6f;
		double vdouble=45.8;
		
		char vchar='f';
		
		boolean vboolean=true;
		
		

	}

}


/*Data Types- what type of value you will store 
8 primitive data types
Integer
byte
short
int
long

Decimal values
float
double

character
char

boolean



Variable- memory location where we are storing some data
*/