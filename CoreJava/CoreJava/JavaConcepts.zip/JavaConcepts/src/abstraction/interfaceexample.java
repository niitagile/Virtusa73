package abstraction;

interface SDLC{
	int maxtime=100;
	void requirement();
	void analysis();
	void design();
}

class WebApplication implements SDLC{

	@Override
	public void requirement() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void analysis() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void design() {
		// TODO Auto-generated method stub
		
	}
	
}
public class interfaceexample {

	public static void main(String[] args) {
		WebApplication obj=new WebApplication();
		obj.requirement();
		obj.analysis();
		obj.design();

	}

}
/* interface- contains only abstract methods and final static variables
 its a contract for a class to fulfill
 interface SDLC{
 	int maxtime=100;
	void requirement();
	void analysis();
	void design();
}
 
 interface SDLC{
 public static final int maxtime=100;// final means fix, static means 1 copy
	public abstract void requirement();
	public abstract void analysis();
	public abstract void design();
}
 
 */