package Inheritence.pkg1;
class SpellChecker{
	void show(String msg) {
		System.out.println("Spell Checking done "+msg);
	}
	
}

class TextEditor{
	String msg;
	SpellChecker sp;
	public TextEditor(String msg, SpellChecker sp) {
		super();
		this.msg = msg;
		this.sp = sp;
	}
	
	void checkSpelling() {
		sp.show(msg);
	}
	
}
public class HasARelationshipExample {

	public static void main(String[] args) {
		TextEditor edit=new TextEditor("Hello All!!!!", new SpellChecker());
		edit.checkSpelling();

	}

}
