package abstraction;
/*interface ParentA{
	void show() ;
}
interface ParentB{
	void show() ;
}
class ChildA implements ParentA,ParentB{

	@Override
	public void show() {
		// TODO Auto-generated method stub
		
	}
	
}
public class multipleinheritenceinterface {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ChildA obj=new ChildA();
		obj.show();

	}

}*/

//to remove diamond proble- implements multiple inheritence through interface