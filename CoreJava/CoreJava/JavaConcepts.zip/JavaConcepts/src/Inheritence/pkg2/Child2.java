package Inheritence.pkg2;

import Inheritence.pkg1.Parent;

public class Child2 extends Parent {

		void show() {
			//method1();
			//method2();
			method3();
			method4();
		}
}
