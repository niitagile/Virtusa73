package BasicConcepts;
class Vehicle{
	private int modelid;
	private float price;
	private String vname;
	Vehicle(int modelid, float p){
		this.modelid=modelid;
		price=p;
	}
	Vehicle (int m ,float p,String n){
		this(m,p);//it must be first lisne
		vname=n;
	}
	void display() {
		
		System.out.println(modelid);
		System.out.println(vname);
		System.out.println(price);
	}
}
public class ThisExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Vehicle v=new Vehicle(12, 20000,"Cycle");
		v.display();
		

	}

}
