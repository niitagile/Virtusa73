package abstraction;
interface interface1{
	void method1();
}
interface interface2 extends interface1{
	void method2();
}

class ClassA implements interface2{

	@Override
	public void method1() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void method2() {
		// TODO Auto-generated method stub
		
	}
	
}
public class interfaceinheritence {
	
	public static void main(String[] args) {
		ClassA obj=new ClassA();
		obj.method1();
		obj.method2();
	}

}
